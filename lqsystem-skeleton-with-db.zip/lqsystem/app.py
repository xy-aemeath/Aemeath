# 项目入口：建表、假数据、托管页面、挂载三个路由模块
import importlib
import importlib.util
import sqlite3
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

import db

BASE_DIR = Path(__file__).parent
STATIC_DIR = BASE_DIR / "static"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

# 表结构以 docs/contracts.md 为准
SCHEMA = """
CREATE TABLE IF NOT EXISTS mentors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  lab TEXT NOT NULL,
  quota INTEGER NOT NULL DEFAULT 3
);

CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  sno TEXT NOT NULL UNIQUE,
  accept_inner INTEGER NOT NULL DEFAULT 1,
  accept_cross INTEGER NOT NULL DEFAULT 1,
  bio TEXT NOT NULL DEFAULT '',
  resume_path TEXT NOT NULL DEFAULT '',
  resume_name TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS rounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  no INTEGER NOT NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'closed' CHECK (status IN ('open', 'closed'))
);

CREATE TABLE IF NOT EXISTS intentions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  round INTEGER NOT NULL,
  UNIQUE (student_id, mentor_id, round)
);

CREATE TABLE IF NOT EXISTS interviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  round INTEGER NOT NULL,
  score_attitude INTEGER,
  score_logic INTEGER,
  score_code INTEGER,
  score_time INTEGER,
  note TEXT
);

CREATE TABLE IF NOT EXISTS offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  round INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'confirmed', 'declined', 'expired')),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS waitlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  round INTEGER NOT NULL,
  rank INTEGER NOT NULL
);
"""

# 3 个实训室 × 2 导师，每人 3 个名额
MENTORS = [
    ("张启明", "A"),
    ("李慧敏", "A"),
    ("王立群", "B"),
    ("赵文轩", "B"),
    ("陈思齐", "C"),
    ("刘佳颖", "C"),
]

# 18 个学生 = 18 个名额（6 位导师 × 3），保证全员可安置
STUDENT_NAMES = [
    "李思远", "王雨桐", "张子墨", "刘欣怡", "陈嘉禾", "杨浩然",
    "赵语萱", "黄铭泽", "周若曦", "吴凯文", "徐一诺", "孙悦然",
    "马骁", "朱清瑶", "胡博文", "郭依依", "何俊熙", "高诗雅",
]

# 轮次是数据不是代码：加一轮只需要加一行
ROUNDS = [
    (1, "第一轮（11.16 – 11.20）", "open"),
    (2, "第二轮补录（11.23 – 11.25）", "closed"),
    (3, "第三轮补录（11.26 – 11.28）", "closed"),
]


def init_db():
    conn = sqlite3.connect(db.DB_PATH)
    try:
        conn.executescript(SCHEMA)
        # 老库补列（新增字段只做增量迁移，不动已有数据）
        cols = {row[1] for row in conn.execute("PRAGMA table_info(students)")}
        for col in ("bio", "resume_path", "resume_name"):
            if col not in cols:
                conn.execute(f"ALTER TABLE students ADD COLUMN {col} TEXT NOT NULL DEFAULT ''")
        conn.commit()
    finally:
        conn.close()


def seed():
    """库为空时才插入假数据"""
    if db.query("SELECT COUNT(*) AS n FROM students")[0]["n"] > 0:
        return

    for name, lab in MENTORS:
        db.execute(
            "INSERT INTO mentors (name, lab, quota) VALUES (?, ?, 3)",
            (name, lab),
        )

    for i, name in enumerate(STUDENT_NAMES):
        db.execute(
            "INSERT INTO students (name, sno, accept_inner, accept_cross, bio) VALUES (?, ?, ?, ?, '')",
            (name, str(2023001 + i), 0 if i in (4, 11) else 1, 0 if i in (6, 14, 21) else 1),
        )

    for no, name, status in ROUNDS:
        db.execute(
            "INSERT INTO rounds (no, name, status) VALUES (?, ?, ?)",
            (no, name, status),
        )


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    seed()
    yield


app = FastAPI(title="学生实训室进组选拔录取系统", lifespan=lifespan)

# 别人的路由模块存在就挂上；不存在也不影响启动
for _name in ("apply", "mentor", "admin"):
    if importlib.util.find_spec(f"routes_{_name}") is None:
        continue
    _module = importlib.import_module(f"routes_{_name}")
    if hasattr(_module, "router"):
        app.include_router(_module.router)


def _page(filename: str, who: str) -> HTMLResponse | FileResponse:
    path = STATIC_DIR / filename
    if path.exists():
        return FileResponse(path)
    return HTMLResponse(
        f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>尚未交付</title></head>
<body><div class="page"><h1 class="title">该页面尚未交付</h1>
<div class="card"><p>此页面由 {who} 负责，文件还没提交。</p>
<p><a href="/">返回首页</a></p></div></div></body></html>"""
    )


@app.get("/", response_class=HTMLResponse)
def index():
    path = STATIC_DIR / "index.html"
    if path.exists():
        return FileResponse(path)
    return HTMLResponse("<h1>系统已启动</h1><p><a href='/apply'>学生填报</a></p>")


@app.get("/health")
def health():
    return {"ok": True}


@app.get("/apply", response_class=HTMLResponse)
def page_apply():
    return _page("apply.html", "1 号")


# 以下页面分别属于 2 号 / 3 号，这里只做跳转占位
@app.get("/mentor", response_class=HTMLResponse)
def page_mentor():
    return _page("mentor.html", "2 号")


@app.get("/my-offers", response_class=HTMLResponse)
def page_my_offers():
    return _page("my-offers.html", "2 号")


@app.get("/admin", response_class=HTMLResponse)
def page_admin():
    return _page("admin.html", "3 号")


@app.get("/public", response_class=HTMLResponse)
def page_public():
    return _page("public.html", "3 号")


@app.get("/debug", response_class=HTMLResponse)
def debug():
    tables = ["mentors", "students", "rounds", "intentions",
              "interviews", "offers", "waitlist"]
    rows = "".join(
        f"<tr><td>{t}</td><td>{db.query(f'SELECT COUNT(*) AS n FROM {t}')[0]['n']}</td></tr>"
        for t in tables
    )
    current = db.query("SELECT no, name FROM rounds WHERE status = 'open' ORDER BY no LIMIT 1")
    current_text = current[0]["name"] if current else "无（当前没有开放轮次）"
    return HTMLResponse(
        f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>调试</title></head>
<body><div class="page"><h1 class="title">调试：各表行数</h1>
<div class="card"><p>当前开放轮次：{current_text}</p>
<table class="table"><thead><tr><th>表</th><th>行数</th></tr></thead>
<tbody>{rows}</tbody></table></div>
<p><a href="/">返回首页</a></p></div></body></html>"""
    )


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")
