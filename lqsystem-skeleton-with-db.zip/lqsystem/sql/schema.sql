-- lqsystem 数据库结构（以 docs/contracts.md 为准）
--
-- 用法（先建表，再灌假数据）：
--   sqlite3 data.db < sql/schema.sql
--   sqlite3 data.db < sql/seed.sql
--
-- 没装 sqlite3 命令行时，可在 lqsystem 目录用 Python 一次执行两个文件：
--   python -c "import sqlite3;c=sqlite3.connect('data.db');c.executescript(open('sql/schema.sql',encoding='utf-8').read());c.executescript(open('sql/seed.sql',encoding='utf-8').read());c.commit()"
--
-- 说明：
-- 1) app.py 启动时会自动建表（并给老库补 students.bio / resume_path / resume_name 三列），
--    所以正常跑服务不需要手动执行本文件；本文件供队友查看结构、或在独立库里初始化用。
-- 2) 语句带 IF NOT EXISTS，重复执行不会破坏已有表；但不会改动已有表结构。
-- 3) students 的 bio / resume_path / resume_name 是在契约基础上追加的字段，已同步到 contracts.md 第 10 节。

CREATE TABLE IF NOT EXISTS mentors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  lab TEXT NOT NULL,
  quota INTEGER NOT NULL DEFAULT 3
);

CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  sno TEXT NOT NULL UNIQUE,
  accept_inner INTEGER NOT NULL DEFAULT 1,
  accept_cross INTEGER NOT NULL DEFAULT 1,
  bio TEXT NOT NULL DEFAULT '',
  resume_path TEXT NOT NULL DEFAULT '',
  resume_name TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS rounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  no INTEGER NOT NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'closed' CHECK (status IN ('open', 'closed'))
);

CREATE TABLE IF NOT EXISTS intentions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  round INTEGER NOT NULL,
  UNIQUE (student_id, mentor_id, round)
);

CREATE TABLE IF NOT EXISTS interviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  round INTEGER NOT NULL,
  score_attitude INTEGER,
  score_logic INTEGER,
  score_code INTEGER,
  score_time INTEGER,
  note TEXT
);

CREATE TABLE IF NOT EXISTS offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  round INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'confirmed', 'declined', 'expired')),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS waitlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mentor_id INTEGER NOT NULL REFERENCES mentors(id),
  student_id INTEGER NOT NULL REFERENCES students(id),
  round INTEGER NOT NULL,
  rank INTEGER NOT NULL
);
