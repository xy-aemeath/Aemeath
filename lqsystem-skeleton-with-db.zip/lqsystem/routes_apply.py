# 学生填报相关接口
import os
import uuid
from pathlib import Path

from fastapi import APIRouter, Query, Request

import db

router = APIRouter(prefix="/api")

BIO_MAX = 500
RESUME_MAX = 5 * 1024 * 1024  # 5MB
RESUME_EXTS = {".pdf", ".doc", ".docx"}
UPLOAD_DIR = Path(__file__).parent / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

STUDENT_FIELDS = (
    "id, name, sno, accept_inner, accept_cross, bio, resume_path, resume_name"
)


def _get_student(student_id=None, sno=None):
    sno = (sno or "").strip()
    if sno:
        rows = db.query(f"SELECT {STUDENT_FIELDS} FROM students WHERE sno = ?", (sno,))
        return rows[0] if rows else None
    if student_id is not None:
        rows = db.query(f"SELECT {STUDENT_FIELDS} FROM students WHERE id = ?", (student_id,))
        return rows[0] if rows else None
    return None


def _open_round():
    rows = db.query(
        "SELECT id, no, name, status FROM rounds WHERE status = 'open' ORDER BY no LIMIT 1"
    )
    return rows[0] if rows else None


def _mentors(round_no=1):
    """第一轮返回全部导师；补录轮（二、三轮）只返回还有空余名额的导师。

    空余名额 = quota - (pending + confirmed)，不分轮次，待确认也占名额（rules.md R18）。
    """
    where = ""
    if round_no and round_no > 1:
        where = "WHERE m.quota - (SELECT COUNT(*) FROM offers o WHERE o.mentor_id = m.id AND o.status IN ('pending', 'confirmed')) > 0"
    return db.query(
        f"""
        SELECT m.id, m.name, m.lab, m.quota,
               (SELECT COUNT(*) FROM offers o
                 WHERE o.mentor_id = m.id AND o.status IN ('pending', 'confirmed')) AS used,
               m.quota - (SELECT COUNT(*) FROM offers o
                 WHERE o.mentor_id = m.id AND o.status IN ('pending', 'confirmed')) AS remaining
          FROM mentors m
          {where}
         ORDER BY m.lab, m.id
        """
    )


def expire_pending_offers(round_no):
    """结算本轮时由管理员侧调用（3 号 /admin 的「结算本轮」）：本轮 pending → expired。

    返回受影响条数。关闭本轮、开启下一轮由调用方在同一个事务里完成；
    这里只负责 offer 状态，不在读取接口里自动触发（rules.md R15）。
    """
    before = db.query(
        "SELECT COUNT(*) AS n FROM offers WHERE round = ? AND status = 'pending'",
        (round_no,),
    )[0]["n"]
    db.execute(
        "UPDATE offers SET status = 'expired' WHERE round = ? AND status = 'pending'",
        (round_no,),
    )
    return before


def _expired_offer(student_id):
    rows = db.query(
        """
        SELECT o.round, o.created_at, m.name AS mentor_name
          FROM offers o JOIN mentors m ON m.id = o.mentor_id
         WHERE o.student_id = ? AND o.status = 'expired'
         ORDER BY o.round DESC, o.id DESC LIMIT 1
        """,
        (student_id,),
    )
    return rows[0] if rows else None


@router.get("/apply")
def get_apply(
    student_id: int | None = Query(None),
    sno: str | None = Query(None),
):
    """带学号就回显该学生的填报；不带学号返回空白表单（可直接填）。"""
    student = _get_student(student_id, sno)
    current = _open_round()

    rounds = db.query("SELECT id, no, name, status FROM rounds ORDER BY no")
    if student is None:
        return {
            "ok": True,
            "data": {
                "student": None,
                "rounds": rounds,
                "current_round": current,
                "can_edit": current is not None,
                "locked_reason": "" if current else "当前没有开放的轮次，填报未开放",
                "mentors": _mentors(current["no"] if current else 1),
                "intentions": [],
                "expired_offer": None,
            },
        }

    sid = student["id"]
    # 没有开放轮次时，回显最近一轮已提交的志愿（只读）
    display = current
    if display is None:
        latest = db.query("SELECT id, no, name, status FROM rounds ORDER BY no DESC LIMIT 1")
        display = latest[0] if latest else None

    confirmed = db.query(
        "SELECT id FROM offers WHERE student_id = ? AND status = 'confirmed' LIMIT 1",
        (sid,),
    )

    if confirmed:
        can_edit, reason = False, "你已被录取，不能再填报"
    elif current is None:
        can_edit, reason = False, "当前没有开放的轮次，填报未开放"
    else:
        can_edit, reason = True, ""

    intentions = []
    if display:
        intentions = db.query(
            "SELECT id, mentor_id FROM intentions WHERE student_id = ? AND round = ? ORDER BY id",
            (sid, display["no"]),
        )

    return {
        "ok": True,
        "data": {
            "student": student,
            "rounds": rounds,
            "current_round": current,
            "can_edit": can_edit,
            "locked_reason": reason,
            "mentors": _mentors(current["no"] if current else 1),
            "intentions": intentions,
            "expired_offer": _expired_offer(sid),
        },
    }


async def _read_submit(request: Request):
    """同时支持 JSON 和 multipart/form-data（带简历文件时用后者）。"""
    ctype = request.headers.get("content-type", "")
    resume = None

    if ctype.startswith("multipart/form-data"):
        form = await request.form()
        resume = form.get("resume")
        if resume is not None and not getattr(resume, "filename", ""):
            resume = None
        return {
            "sno": str(form.get("sno") or ""),
            "name": str(form.get("name") or ""),
            "mentor_ids": form.getlist("mentor_ids"),
            "accept_inner": form.get("accept_inner"),
            "accept_cross": form.get("accept_cross"),
            "bio": str(form.get("bio") or ""),
        }, resume

    data = await request.json()
    return {
        "sno": str(data.get("sno") or ""),
        "name": str(data.get("name") or ""),
        "mentor_ids": data.get("mentor_ids") or [],
        "accept_inner": data.get("accept_inner"),
        "accept_cross": data.get("accept_cross"),
        "bio": str(data.get("bio") or ""),
    }, None


@router.post("/intentions")
async def save_intentions(request: Request):
    payload, resume_file = await _read_submit(request)

    sno = payload["sno"].strip()
    name = payload["name"].strip()
    if not sno:
        return {"ok": False, "msg": "请输入学号"}
    if not name:
        return {"ok": False, "msg": "请输入姓名"}

    try:
        mentor_ids = []
        for raw in payload["mentor_ids"]:
            for piece in str(raw).split(","):
                piece = piece.strip()
                if piece:
                    mentor_ids.append(int(piece))
    except ValueError:
        return {"ok": False, "msg": "志愿数据格式错误"}

    current = _open_round()
    if current is None:
        return {"ok": False, "msg": "当前没有开放的轮次，填报未开放"}

    if not mentor_ids:
        return {"ok": False, "msg": "请至少选择 1 个导师志愿"}
    if len(mentor_ids) > 3:
        return {"ok": False, "msg": "最多只能填报 3 个志愿"}
    if len(set(mentor_ids)) != len(mentor_ids):
        return {"ok": False, "msg": "同一位导师不能重复填报"}

    accept_inner_raw = payload["accept_inner"]
    accept_cross_raw = payload["accept_cross"]
    if accept_inner_raw is None or str(accept_inner_raw).strip() == "":
        return {"ok": False, "msg": "请选择实训室内调剂意愿"}
    if accept_cross_raw is None or str(accept_cross_raw).strip() == "":
        return {"ok": False, "msg": "请选择跨实训室调剂意愿"}

    bio = payload["bio"].strip()
    if not bio:
        return {"ok": False, "msg": "请填写个人简介"}
    if len(bio) > BIO_MAX:
        return {"ok": False, "msg": f"个人简介不能超过 {BIO_MAX} 字"}

    if mentor_ids:
        marks = ",".join("?" * len(mentor_ids))
        found = db.query(f"SELECT id FROM mentors WHERE id IN ({marks})", tuple(mentor_ids))
        if len(found) != len(mentor_ids):
            return {"ok": False, "msg": "导师不存在"}

    # 补录轮不接受已无名额导师的志愿
    if mentor_ids and current["no"] > 1:
        available = {m["id"] for m in _mentors(current["no"])}
        if any(mid not in available for mid in mentor_ids):
            return {"ok": False, "msg": "所选导师在补录轮已无名额"}

    # 补录轮不收集简历：即使收到文件也不落盘
    if current["no"] > 1:
        resume_file = None

    existing = db.query("SELECT id, resume_path FROM students WHERE sno = ?", (sno,))
    if existing:
        confirmed = db.query(
            "SELECT id FROM offers WHERE student_id = ? AND status = 'confirmed' LIMIT 1",
            (existing[0]["id"],),
        )
        if confirmed:
            return {"ok": False, "msg": "你已被录取，不能再填报"}

    # 简历文件：只落盘，路径和原始文件名随提交一起写库
    new_resume = None
    if resume_file is not None:
        original = os.path.basename(str(resume_file.filename or "")).strip()
        ext = os.path.splitext(original)[1].lower()
        if ext not in RESUME_EXTS:
            return {"ok": False, "msg": "简历只支持 pdf / doc / docx 格式"}
        content = await resume_file.read()
        if len(content) > RESUME_MAX:
            return {"ok": False, "msg": "简历文件不能超过 5MB"}
        if not content:
            return {"ok": False, "msg": "简历文件为空"}
        stored = uuid.uuid4().hex + ext
        (UPLOAD_DIR / stored).write_bytes(content)
        new_resume = (stored, original[:120])

    accept_inner = 1 if str(payload["accept_inner"]) not in ("", "0", "False", "false") else 0
    accept_cross = 1 if str(payload["accept_cross"]) not in ("", "0", "False", "false") else 0

    # 一个事务：学号不存在就建号 + 改学生资料 + 整体覆盖本轮志愿（规则 R4 / R12）
    with db.transaction() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO students (name, sno, accept_inner, accept_cross, bio)"
            " VALUES (?, ?, 1, 1, '')",
            (name, sno),
        )
        row = conn.execute(
            "SELECT id, name, resume_path FROM students WHERE sno = ?", (sno,)
        ).fetchone()
        sid = row["id"]
        final_name = (row["name"] or "").strip()
        if name and not final_name:
            conn.execute("UPDATE students SET name = ? WHERE id = ?", (name, sid))
            final_name = name

        conn.execute(
            "UPDATE students SET accept_inner = ?, accept_cross = ?, bio = ? WHERE id = ?",
            (accept_inner, accept_cross, bio, sid),
        )
        if new_resume:
            conn.execute(
                "UPDATE students SET resume_path = ?, resume_name = ? WHERE id = ?",
                (new_resume[0], new_resume[1], sid),
            )
        old_resume = (row["resume_path"] or "").strip()
        conn.execute(
            "DELETE FROM intentions WHERE student_id = ? AND round = ?",
            (sid, current["no"]),
        )
        for mentor_id in mentor_ids:
            conn.execute(
                "INSERT INTO intentions (student_id, mentor_id, round) VALUES (?, ?, ?)",
                (sid, mentor_id, current["no"]),
            )

    # 换新文件后删掉旧文件，避免 uploads 目录越堆越多
    if new_resume and old_resume and old_resume != new_resume[0]:
        old_path = UPLOAD_DIR / os.path.basename(old_resume)
        if old_path.exists():
            old_path.unlink()

    return {
        "ok": True,
        "data": {
            "round": current["no"],
            "mentor_ids": mentor_ids,
            "student": {"id": sid, "sno": sno, "name": name, "created": not existing},
        },
    }
