# 数据库访问：所有人共用这两个函数
import sqlite3
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(__file__).with_name("data.db")


def _connect():
    conn = sqlite3.connect(DB_PATH, timeout=5, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def query(sql, params=()):
    """查询，返回 list[dict]"""
    conn = _connect()
    try:
        rows = conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def execute(sql, params=()):
    """写入（自动提交），返回 lastrowid"""
    conn = _connect()
    try:
        cur = conn.execute(sql, params)
        return cur.lastrowid
    finally:
        conn.close()


@contextmanager
def transaction():
    """事务：查状态 + 改状态必须在同一个事务里（规则 R12）"""
    conn = _connect()
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise
    finally:
        conn.close()
